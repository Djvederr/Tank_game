import pygame
import math
pygame.init()

from pygame.locals import (
    K_w,
    K_s,
    K_a,
    K_d,
    K_q,
    K_e,
    K_ESCAPE,
    K_RETURN,
    KEYDOWN,
    QUIT,
)

TURN_MOVES=6
PLAYER_LEFT=0
PLAYER_RIGHT=1
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
FLOOR_HEIGHT=40
WALL_HEIGHT=150
WALL_WIDTH=50
FLOOR_COLOUR=(101, 186, 45)
WALL_COLOUR=(128, 128, 128)
BG_COLOUR=(0,0,0)
PROMPT=pygame.Rect(200,200,400,200)
PROMPT_BUTTON=pygame.Rect((SCREEN_WIDTH/2)-(80/2),360,80,30)
FLOOR=pygame.Rect(0,SCREEN_HEIGHT-FLOOR_HEIGHT,SCREEN_WIDTH,FLOOR_HEIGHT)
WALL=pygame.Rect((SCREEN_WIDTH/2)-(WALL_WIDTH/2),SCREEN_HEIGHT-FLOOR_HEIGHT-WALL_HEIGHT,WALL_WIDTH,WALL_HEIGHT)
window = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
prompt_font1 = pygame.font.SysFont(None, 25)
prompt_font2 = pygame.font.SysFont(None, 40)
game_loser=None
game_running=True
turn=0
COLOR = (255, 100, 98)

def game_done(side):
    global game_loser
    game_loser=side

def draw_bg():
    window.fill(BG_COLOUR)
    pygame.draw.rect(window,FLOOR_COLOUR,FLOOR)
    pygame.draw.rect(window,WALL_COLOUR,WALL)
    if game_loser!=None:
        if game_loser==0:
            name="Player right"
        else:
            name="Player left"
        pygame.draw.rect(window,WALL_COLOUR, PROMPT)
        pygame.draw.rect(window,(0,0,0),PROMPT_BUTTON)
        text1 = prompt_font2.render("GAME OVER", True, (255, 255, 255))
        text2 = prompt_font1.render(f"{name} won!", True, (255, 255, 255))
        text3 = prompt_font1.render("EXIT",True,(255, 255, 255))
        window.blit(text1, (210, 210))
        window.blit(text2, (210, 240))
        window.blit(text3, ((SCREEN_WIDTH/2)-(80/2)+10,360+7))
PLAYER_HEIGHT=35
PLAYER_WIDTH=64
Left_player_image=pygame.image.load("Player_left.png")
Right_player_image=pygame.image.load("Player_right.png")
class Player(pygame.sprite.Sprite):


    def __init__(self,colour,side):
        super(Player, self).__init__()
        self.colour=colour
        self.side=side
        self.image=pygame.Surface((PLAYER_WIDTH,PLAYER_HEIGHT))
        self.rect=self.image.get_rect()
        if side==PLAYER_LEFT:
            self.image.blit(Left_player_image, (0, 0))
            self.rect.x=10
        elif side==PLAYER_RIGHT:
            self.image.blit(Right_player_image, (0, 0))
            self.rect.x=SCREEN_WIDTH-10-PLAYER_WIDTH
        self.rect.y = SCREEN_HEIGHT - FLOOR_HEIGHT - PLAYER_HEIGHT
        self.start_x=self.rect.x
        self.health=4

    def update(self,key):
        global turn,HIT
        if FIRING:
            return
        if key==K_RETURN:
            self.start_x = self.rect.x
            return
        if turn%2==self.side:
            if key==K_a:
                self.rect.x-=10
                if pygame.Rect.colliderect(self.rect,WALL):
                    self.rect.x+=10
                if abs(self.start_x-self.rect.x) > TURN_MOVES*10 :
                    self.rect.x += 10
            if key==K_d:
                self.rect.x+=10
                if pygame.Rect.colliderect(self.rect,WALL):
                    self.rect.x-=10
                if abs(self.start_x-self.rect.x) > TURN_MOVES*10 :
                    self.rect.x -= 10
        if key=="hit" and turn%2==self.side:
            self.health-=1
            if self.health==0:
                game_done(self.side)
            HIT = False
            print(self.health)


    def change_turn(self):
        self.start_x=self.rect.x

class HealthBar(pygame.sprite.Sprite):

    def __init__(self, connection):
        super(HealthBar, self).__init__()
        self.connection=connection
        self.side = connection.side
        self.image = pygame.Surface((PLAYER_WIDTH-10, 10))
        self.image.fill((255, 0, 0))
        self.rect = self.image.get_rect()
        self.rect.x=connection.rect.x+5
        self.rect.y =connection.rect.y-20
        self.start_x = self.rect.x

    def update(self):
        self.rect.x=self.connection.rect.x+5
        self.rect.y =self.connection.rect.y - 20
        self.image.fill((128, 128, 128))
        pygame.draw.rect(self.image, (255, 0, 0), pygame.Rect(0, 0, (PLAYER_WIDTH - 10) * (self.connection.health / 4), 10))



class Gun(pygame.sprite.Sprite):

    def __init__(self, connection):
        super(Gun, self).__init__()
        self.connection=connection
        self.image = pygame.Surface((PLAYER_WIDTH - 10, 10))



class Message(pygame.sprite.Sprite):

    def __init__(self,message_side):
        super(Message, self).__init__()
        self.image=pygame.Surface((150,100))
        self.rect = self.image.get_rect()
        self.font1 = pygame.font.SysFont(None, 25)
        self.a=60
        self.v=100
        self.side=message_side
        m=[f"angle: {self.a}",f"velocity: {self.v}"]
        text1= self.font1.render(m[0], True, (255, 255, 255))
        text2 = self.font1.render(m[1], True, (255, 255, 255))
        self.image.blit(text1,(0,0))
        self.image.blit(text2, (0, 20))
        if message_side==PLAYER_LEFT:
            self.rect.x=10
            self.rect.y=10
        else:
            self.rect.x = SCREEN_WIDTH-150-10
            self.rect.y = 10

    def update(self,key):
        if FIRING:
            return
        if turn%2==self.side:
            if key==K_q and self.a>10:
                self.a-=5
            elif key==K_e and self.a<85:
                self.a+=5
            elif key==K_w and self.v<100:
                self.v+=5
            elif key==K_s and self.v>5:
                self.v-=5
        m = [f"angle: {self.a}", f"velocity: {self.v}"]
        text1 = self.font1.render(m[0], True, (255, 255, 255))
        text2 = self.font1.render(m[1], True, (255, 255, 255))
        self.image.fill((0,0,0))
        self.image.blit(text1, (0, 0))
        self.image.blit(text2, (0, 20))

    def get_values(self):
        return[self.a,self.v]


class Bullet(pygame.sprite.Sprite):
    def __init__(self, color, height, width,start_x,start_y):
        super().__init__()

        self.image = pygame.Surface([width, height])
        self.width = width
        self.color = color
        self.image.fill((0,0,0))
        self.image.set_colorkey(COLOR)
        pygame.draw.circle(self.image, color, [width / 2, width / 2], width / 2)

        self.rect = self.image.get_rect()
        self.rect.x=start_x
        self.rect.x=start_y
        self.time = 0
        self.startRect = self.image.get_rect()
        self.startRect.x=start_x
        self.startRect.y = start_y
        print("start : ", self.startRect.x, self.startRect.y)

    def update(self,info):
        global FIRING,HIT
        if turn%2!=PLAYER_LEFT:
            angle,speed=info
            angle=math.radians(angle)
            if self.rect.y <= SCREEN_HEIGHT-FLOOR_HEIGHT-20:
                self.time += 0.05
                velx = math.cos(angle) * speed
                vely = math.sin(angle) * speed
                dx = velx * self.time
                dy = (vely * self.time) + ((-9.81 * (self.time ** 2)) / 2)
                self.rect.x = self.startRect.x + dx
                self.rect.y = self.startRect.y - dy
                if  pygame.Rect.colliderect(self.rect,WALL) or self.rect.x>=SCREEN_WIDTH:
                    FIRING = False
                    bullets.empty()
                elif pygame.Rect.colliderect(self.rect, player1.rect):
                    print("Hit!")
                    HIT = True
                    FIRING = False
                    bullets.empty()
            else:
                FIRING = False
                bullets.empty()
        else:
            angle, speed = info
            angle = math.radians(angle)
            if self.rect.y<=SCREEN_HEIGHT-FLOOR_HEIGHT-20:
                self.time+=0.05
                velx=math.cos(angle)*speed
                vely=math.sin(angle)*speed
                dx=  velx*self.time
                dy=(vely*self.time)+((-9.81*(self.time**2))/2)
                self.rect.x=self.startRect.x-dx
                self.rect.y=self.startRect.y-dy
                if pygame.Rect.colliderect(self.rect, WALL) or self.rect.x<=0:
                    FIRING = False
                    bullets.empty()
                elif pygame.Rect.colliderect(self.rect, player2.rect):
                    print("Hit!")
                    HIT=True
                    FIRING = False
                    bullets.empty()
            else:
                bullets.empty()
                FIRING=False

clock = pygame.time.Clock()
HIT=False
player=True
FIRING=False
bullets= pygame.sprite.Group()

def shoot():
    global player
    print(turn)
    print(player)
    if player:
        start_x, start_y=[player2.rect.x,player2.rect.y]
    else:
        start_x, start_y = [player1.rect.x, player1.rect.y]
    bullet=Bullet((255,255,255),25,25,start_x,start_y)
    bullets.add(bullet)




players=pygame.sprite.Group()
messages=pygame.sprite.Group()
healthbars=pygame.sprite.Group()

player1=Player((0,255,255),PLAYER_RIGHT)
player2=Player((255,0,255),PLAYER_LEFT)

healthbar1=HealthBar(player1)
healthbar2=HealthBar(player2)

message1=Message(PLAYER_RIGHT)
message2=Message(PLAYER_LEFT)

players.add(player1)
players.add(player2)

messages.add(message1)
messages.add(message2)

healthbars.add(healthbar1)
healthbars.add(healthbar2)

while game_running:
    player=(turn%2)==PLAYER_LEFT
    if HIT:
        players.update("hit")
    for event in pygame.event.get():
        if event.type==KEYDOWN and game_loser==None:
            if event.key==K_ESCAPE:
                game_running=False
            else:
                if event.key==K_RETURN and not FIRING:
                    turn+=1
                    FIRING = True
                    shoot()
                messages.update(event.key)
                players.update(event.key)

        elif event.type==QUIT:
            game_running=False

        elif event.type==pygame.MOUSEBUTTONDOWN and game_loser!=None:
            (x,y)=pygame.mouse.get_pos()
            if (x>=(SCREEN_WIDTH / 2) - (80 / 2) and x<=((SCREEN_WIDTH / 2) - (80 / 2))+80) and (y>=360 and y<=360+30):
                game_running = False
    draw_bg()

    if player:
        clock.tick(60)
        bullets.update(message1.get_values())
        bullets.draw(window)
    else:
        clock.tick(60)
        bullets.update(message2.get_values())
        bullets.draw(window)
    players.draw(window)
    messages.draw(window)
    healthbars.update()
    healthbars.draw(window)

    pygame.display.flip()
