hi=[1,2]
hi1,hi2=hi
print(hi1)